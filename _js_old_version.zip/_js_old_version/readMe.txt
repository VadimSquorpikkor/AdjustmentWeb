09.02.22
Начало глобальной переделки:
1. переход на хранение location states devices dev_set employees в коде JS, из БД будут загружаться только unit и event
2. отказ от id (id теперь — это имя документа БД), отках от JOIN, отказ от name_id

 
